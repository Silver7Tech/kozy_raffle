# KOZY RUFFLE

## How to install

    yarn

## How to start

    yarn start

## Init the account

    If you run the project first time, please init the vault account and entrants account

    How?

    Please approve the 2 transactions when you run the project first time

## deposit the kozy token to the treasury wallet

    Please 1 $kozy to the treasury wallet at least